package com.anbernic.consoleui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Lightweight console launcher for Anbernic RG556.
 *
 * Developer mode is intentionally session-only: it is held in RAM and is not
 * persisted. A reboot/process death therefore hides the developer panel again.
 *
 * This first public build uses a local mock account store. The AccountRepository
 * interface is designed so FirebaseAuth/Firestore can be added later without
 * changing the UI layer.
 */
public class MainActivity extends Activity {
    private LinearLayout root, content;
    private boolean developerMode = false;
    private int selected = 0;
    private final List<Button> homeButtons = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        showHome();
    }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(24, 10, 24, 10);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setFocusable(true);
        b.setMinHeight(90);
        b.setOnFocusChangeListener((v, has) -> {
            v.setAlpha(has ? 1f : .72f);
            v.setScaleX(has ? 1.03f : 1f);
            v.setScaleY(has ? 1.03f : 1f);
        });
        return b;
    }

    private void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(38, 28, 38, 28);
        root.setBackgroundColor(Color.rgb(7,11,16));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView profile = text("●  Player  •  21,337 G", 18);
        profile.setTextColor(Color.rgb(244,247,250));
        top.addView(profile, new LinearLayout.LayoutParams(0, 65, 1));

        TextView nav = text("▤    ▦    ◉    ⌕    ⚙", 22);
        nav.setGravity(Gravity.CENTER);
        top.addView(nav, new LinearLayout.LayoutParams(420, 65));
        root.addView(top);

        root.addView(text(title, 28), new LinearLayout.LayoutParams(-1, 70));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
    }

    private void showHome() {
        base("HOME");
        homeButtons.clear();

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button hero = button("STARFIELD\nContinue playing");
        hero.setTextSize(21);
        hero.setBackgroundColor(Color.rgb(27,42,50));
        hero.setOnClickListener(v -> Toast.makeText(this, "Game launch hook ready", Toast.LENGTH_SHORT).show());
        row.addView(hero, new LinearLayout.LayoutParams(300, 390));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        String[] games = {"Browse your games", "Favorites", "Recently played", "Add applications"};
        for (String g : games) {
            Button b = button(g);
            b.setBackgroundColor(Color.rgb(16,24,32));
            right.addView(b, new LinearLayout.LayoutParams(-1, 86));
            if (g.equals("Browse your games")) b.setOnClickListener(v -> showLibrary());
            if (g.equals("Add applications")) b.setOnClickListener(v -> pickApk("Select application APK"));
            homeButtons.add(b);
        }
        row.addView(right, new LinearLayout.LayoutParams(0, -1, 1));
        content.addView(row);

        TextView hint = text("A/B: select   D-pad: navigate   START: settings", 15);
        hint.setTextColor(Color.rgb(168,179,189));
        content.addView(hint, new LinearLayout.LayoutParams(-1, 55));

        hero.requestFocus();
    }

    private void showLibrary() {
        base("MY GAMES");
        String[] games = {"Starfield", "Forza Horizon 5", "Minecraft", "Diablo", "Assassin's Creed Mirage", "Ghostwire Tokyo"};
        for (String g : games) {
            Button b = button("▶  " + g);
            b.setBackgroundColor(Color.rgb(16,24,32));
            b.setOnClickListener(v -> Toast.makeText(this, "Launch: " + g, Toast.LENGTH_SHORT).show());
            content.addView(b, new LinearLayout.LayoutParams(-1, 68));
        }
        Button back = button("Back");
        back.setOnClickListener(v -> showHome());
        content.addView(back, new LinearLayout.LayoutParams(-1, 68));
    }

    private void showSettings() {
        base("SETTINGS");
        String[] items = {
                "Display & orientation",
                "Controller",
                "Accounts",
                "Add applications",
                "System update",
                "Developer panel"
        };
        for (String s : items) {
            Button b = button(s);
            b.setBackgroundColor(Color.rgb(16,24,32));
            content.addView(b, new LinearLayout.LayoutParams(-1, 68));
            if (s.equals("Add applications")) b.setOnClickListener(v -> pickApk("Select application APK"));
            if (s.equals("System update")) b.setOnClickListener(v -> pickApk("Select launcher update APK"));
            if (s.equals("Accounts")) b.setOnClickListener(v -> showAccounts());
            if (s.equals("Developer panel")) b.setOnClickListener(v -> showDeveloper());
        }
        Button home = button("Back to home");
        home.setOnClickListener(v -> showHome());
        content.addView(home, new LinearLayout.LayoutParams(-1, 68));
    }

    private void showAccounts() {
        base("ACCOUNT");
        content.addView(text("Local profile", 23));
        content.addView(text("Player\nGamertag: PLAYER-556\nScore: 21,337 G", 18));
        Button create = button("Create another local profile");
        create.setOnClickListener(v -> Toast.makeText(this, "Local mock account created", Toast.LENGTH_SHORT).show());
        content.addView(create, new LinearLayout.LayoutParams(-1, 72));
        Button back = button("Back");
        back.setOnClickListener(v -> showSettings());
        content.addView(back, new LinearLayout.LayoutParams(-1, 72));
    }

    private void showDeveloper() {
        base("DEVELOPER PANEL");
        if (!developerMode) {
            Button unlock = button("Unlock developer mode\nTap 7 times");
            final int[] taps = {0};
            unlock.setOnClickListener(v -> {
                taps[0]++;
                if (taps[0] >= 7) {
                    developerMode = true;
                    showDeveloper();
                } else {
                    Toast.makeText(this, "Developer unlock: " + taps[0] + "/7", Toast.LENGTH_SHORT).show();
                }
            });
            content.addView(unlock, new LinearLayout.LayoutParams(-1, 110));
        } else {
            content.addView(text("Developer mode is active for this session only.", 17));
            String[] dev = {
                    "Debug overlay",
                    "Reset local account data",
                    "Clear launcher cache",
                    "Open Android app settings",
                    "Install test APK",
                    "System information"
            };
            for (String d : dev) {
                Button b = button(d);
                b.setBackgroundColor(Color.rgb(16,24,32));
                content.addView(b, new LinearLayout.LayoutParams(-1, 65));
                if (d.equals("Open Android app settings")) {
                    b.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName()))));
                }
                if (d.equals("Reset local account data")) {
                    b.setOnClickListener(v -> Toast.makeText(this, "Mock account data reset", Toast.LENGTH_SHORT).show());
                }
                if (d.equals("Install test APK")) b.setOnClickListener(v -> pickApk("Select APK"));
            }
        }
        Button back = button("Back");
        back.setOnClickListener(v -> showSettings());
        content.addView(back, new LinearLayout.LayoutParams(-1, 68));
    }

    private void pickApk(String title) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/vnd.android.package-archive");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, 44);
        Toast.makeText(this, title, Toast.LENGTH_SHORT).show();
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r,c,d);
        if (r == 44 && c == RESULT_OK && d != null && d.getData() != null) {
            Uri uri = d.getData();
            try {
                Intent install = new Intent(Intent.ACTION_VIEW);
                install.setDataAndType(uri, "application/vnd.android.package-archive");
                install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(install);
            } catch (Exception e) {
                Toast.makeText(this, "Android package installer unavailable", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BUTTON_START || keyCode == KeyEvent.KEYCODE_MENU) {
            showSettings();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
